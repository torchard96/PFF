Just some documention on variable defintions

Player:
	Jump_force:  force applied when player jumps
	DoublejumpfTime:  how much time the player stays in the air after a double jump
	Gravity_acc:  gravitional acceleration
	GroundCheckDistance:  distance used in checking isGrounded
	PlayerMovmentForce:  force applied by pressing movment keys
	CoffOfDrag:  drag force multiplier (note PlayerMovmentForce and CoffOfDrag ratio very strongly determines how game feels)
	Drag_in_air:  weither drag is applied while the player is in the air (note turning this off means the players could get some serious speed if they just keep jumping)
	Ghost_time:  how long to wait after the player falls off a ledge before they can't jump (used to fight latency both in screen and in input)
