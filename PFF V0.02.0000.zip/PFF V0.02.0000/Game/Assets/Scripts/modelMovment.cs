﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class modelMovment : MonoBehaviour {

    Transform position;
    Rigidbody parentPhysics;
    Vector2 location;
    float angle;

	// Use this for initialization
	void Start ()
    {
        position = GetComponent<Transform>();
        parentPhysics = position.parent.GetComponent<Rigidbody>();
	}

    // Update is called once per frame
    void LateUpdate ()
    {
        position.LookAt(parentPhysics.velocity);
	}
}
