﻿using UnityEngine;

public class PlayerController : MonoBehaviour {

    //variables that can be Changed
    [SerializeField] float jump_force = 5f;
    [Range(0f,2f)][SerializeField] float doublejumpfTime = 0.2f;
    [Range(0f,50f)][SerializeField] float gravity_acc = 9.81f;
    [SerializeField] float groundCheckDistance = 0.1f;
    [SerializeField] float playerMovmentForce = 10f;
    [SerializeField] float coffOfDrag = 1f;
    [SerializeField] bool drag_in_air = true;
    [Range(0,0.1f)][SerializeField] float ghost_time = 0.05f;
    [SerializeField] float jumpAngleLimit = 60f;
    [SerializeField] float walkAngleLimit = 45f;


    //variables that are not to be changed
    Rigidbody objectPhysics;
    CapsuleCollider Collider;
    private float disToGround;
    private bool canDoubleJump;
    private float canJumptimer;
    private float doubleJumptimer = 0;
    float camRot;
    private float playerAngle = 0f;
    private bool impacted = true;
    Vector2 impactDirection = Vector2.zero;

    // Use this for initialization
    void Start ()
    {
        Collider = GetComponent<CapsuleCollider>();
        objectPhysics = GetComponent<Rigidbody>();
        objectPhysics.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
        disToGround = Collider.bounds.extents.y;
        camRot = Camera.main.transform.eulerAngles.y;
    }
	
    //uses raycaster to check distance to ground
    bool IsGrounded()
    {
        return (playerAngle <= jumpAngleLimit && impacted);
    }

    bool IsSliding()
    {
        return (playerAngle >= walkAngleLimit && impacted);
    }

	// Update is called once per frame
	void Update ()
    {
        HandleMovment();
        HandleJump();
        Gravity();
        camRot = -Camera.main.transform.eulerAngles.y;
	}

    //name says it all
    void HandleMovment()
    {
        //2d vector of where the player wants to go
        Vector2 movment = new Vector2(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical")) * playerMovmentForce;
        movment = VectorRotate(movment, camRot);
        if(IsSliding())
        {
            movment = impactDirection*playerMovmentForce;
        }
        if (IsGrounded() || drag_in_air)
        {
            //2d drag vector
            Vector2 drag = new Vector2(-objectPhysics.velocity.x,-objectPhysics.velocity.z) * coffOfDrag;
            //adds movement and drag
            movment = movment + drag;
        }
        
        //stops velovity if player is barrely moving
        if (movment.sqrMagnitude<0.01 && new Vector2(objectPhysics.velocity.x,objectPhysics.velocity.z).sqrMagnitude<0.01)
        {
            Vector3 velocity = objectPhysics.velocity;
            velocity.x = 0;
            velocity.z = 0;
            objectPhysics.velocity = velocity;
        }
        //adds force to player
        objectPhysics.AddForce(new Vector3(movment.x, 0, movment.y));
    }

    //handles jumping
    void HandleJump()
    {
        //resets jumping info
        if (IsGrounded())
        {
            canJumptimer = ghost_time;
            canDoubleJump = true;
            doubleJumptimer = 0;
        }

        //get player input and jumps
        if (Input.GetKeyDown("space") && canJumptimer>0)
        {
            Vector3 v = objectPhysics.velocity;
            v.y = 0;
            objectPhysics.velocity = v;
            objectPhysics.AddForce(new Vector3(0, jump_force, 0), ForceMode.Impulse);
            canJumptimer = 0;
        }

        //double jumpcode
        if (Input.GetKeyDown("space") && canJumptimer<0 && canDoubleJump)
        {
            canDoubleJump = false;
            doubleJumptimer = doublejumpfTime;
        }

        //if player double jumped this keeps them in the air
        if (doubleJumptimer>0)
        {
            Vector3 v = objectPhysics.velocity;
            v.y = 0;
            objectPhysics.velocity = v;
        }

        //updates timers
        canJumptimer -= Time.deltaTime;
        doubleJumptimer -= Time.deltaTime;
    }

    //unrelenting gravity
    void Gravity()
    {
        objectPhysics.AddForce(new Vector3(0, -gravity_acc, 0));
    }

    void OnCollisionStay(Collision hit)
    {
        impacted = true;
        impactDirection = new Vector2 (hit.contacts[0].normal.x, hit.contacts[0].normal.z);
        playerAngle = Vector3.Angle(Vector3.up, hit.contacts[0].normal); //Calc angle between normal and character
    }

    private void OnCollisionExit(Collision hit)
    {
        impacted = false;
    }

    Vector2 VectorRotate(Vector2 v,float degrees)
    {
        return Quaternion.Euler(0, 0, degrees) * v;
    }
}
