﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    //Changable stuff
    [SerializeField] private float sensivityX = 4f;
    [SerializeField] private float sensivityY = 1f;
    [SerializeField] private float distance = 5f;
    [SerializeField] private const float MAXANGLE = 75f;

    //setting up camera
    public Transform lookAt;
    public Transform cameraPosition;

    //private Camera cam;

    private float currentX = 0f;
    private float currentY = 0f;

    private void Start()
    {
        //still setting up camera
        cameraPosition = transform;
        //cam = Camera.main;
    }

    private void Update()
    {
        //sets and limits camera angles
        currentX += Input.GetAxis("MouseX") * sensivityX;
        currentY += Input.GetAxis("MouseY") * sensivityY;

        currentY = Mathf.Clamp(currentY, -MAXANGLE, MAXANGLE);
    }

    private void LateUpdate()
    {
        //stuff I barely understand to move the camera
        Vector3 dir = new Vector3(0, 0, -distance);
        Quaternion rotation = Quaternion.Euler(currentY, currentX, 0);
        cameraPosition.position = lookAt.position + rotation * dir;
        cameraPosition.LookAt(lookAt.position);
    }
}
